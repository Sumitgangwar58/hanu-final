import React from "react";

const Logo = () => {
  return <h1>Kalyani Farms</h1>;
};

export default Logo;
