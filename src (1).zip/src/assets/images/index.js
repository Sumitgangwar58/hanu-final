import image1 from "./WhatsApp Image 2024-07-22 at 11.11.38 AM.jpeg";
import image2 from "./WhatsApp Image 2024-07-22 at 11.11.39 AM (1).jpeg";
import image3 from "./WhatsApp Image 2024-07-22 at 11.11.39 AM.jpeg";
import image4 from "./WhatsApp Image 2024-07-22 at 11.11.40 AM (1).jpeg";
import image5 from "./WhatsApp Image 2024-07-22 at 11.11.40 AM (2).jpeg";
import image6 from "./WhatsApp Image 2024-07-22 at 11.11.40 AM.jpeg";
import image7 from "./WhatsApp Image 2024-07-22 at 11.11.41 AM (1).jpeg";
import image8 from "./WhatsApp Image 2024-07-22 at 11.11.41 AM.jpeg";
import image9 from "./WhatsApp Image 2024-07-22 at 11.11.42 AM (1).jpeg";
import image10 from "./WhatsApp Image 2024-07-22 at 11.11.42 AM.jpeg";
import image11 from "./WhatsApp Image 2024-07-22 at 11.11.44 AM.jpeg";

import KittyParty from "./Gemini_Generated_Image_7aobb07aobb07aob.jpeg";
import SocialGathering from "./Gemini_Generated_Image_7lt0zj7lt0zj7lt0.jpeg";
import Catering from "./Gemini_Generated_Image_ajj6u7ajj6u7ajj6.jpeg";
import BirthdayParty from "./Gemini_Generated_Image_sn2o2dsn2o2dsn2o.jpeg";
import Wedding from "./Gemini_Generated_Image_f6nxr1f6nxr1f6nx.jpeg";
import CorporateEvents from "./Gemini_Generated_Image_6mu9jl6mu9jl6mu9.jpeg";

const images = [
  image1,
  image2,
  image3,
  image4,
  image5,
  image6,
  image7,
  image8,
  image9,
  image10,
  image11,
];

export const servicesImages = [
  KittyParty,
  Wedding,
  SocialGathering,
  BirthdayParty,
  CorporateEvents,
  Catering,
];
export default images;
